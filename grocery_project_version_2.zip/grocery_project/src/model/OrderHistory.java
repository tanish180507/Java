package model;

import util.DataStore;
import util.Logger;
import java.util.*;

public class OrderHistory {
    private List<Order> orders;
    private DataStore ds;
    private String file = "data/orders.csv";

    public OrderHistory() {
        orders = new ArrayList<>();
        ds = DataStore.getInstance();
        loadOrders();
    }

    private void loadOrders() {
        List<String> lines = ds.readCSV(file);
        for(String line : lines) {
            Order o = Order.fromCSV(line);
            if(o != null) orders.add(o);
        }
    }

    public void addOrder(Order o) {
        orders.add(o);
        ds.appendCSV(file, o.toCSV());
        Logger.getInstance().log("Order " + o.getOrderId() + " by " + o.getUsername() + " processed.");
    }

    public void displayHistory() {
        if(orders.isEmpty()) {
            System.out.println("No orders yet.");
            return;
        }
        System.out.println("=== Order History ===");
        for(Order o : orders) {
            System.out.println("Order ID: " + o.getOrderId() + " | User: " + o.getUsername());
            for(Map.Entry<Product, Double> e : o.getBasket().getItems().entrySet()) {
                Product p = e.getKey();
                System.out.printf("%-5s %-15s %-10s %-5.2f %-7.2f\n",
                    p.getId(), p.getName(), p.getCategory(), e.getValue(), p.getPricePerKg()*e.getValue());
            }
            System.out.println("----------------------");
        }
    }

    public List<Order> getOrders() {
        return orders;
    }
}
