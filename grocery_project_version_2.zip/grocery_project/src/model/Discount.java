package model;

public abstract class Discount {
    protected String name;

    public Discount(String name){
        this.name = name;
    }

    // calculate discount amount based on total
    public abstract double apply(double total);

    public String getName() {
        return name;
    }
}
