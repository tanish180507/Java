package model;

import java.util.Map;
import java.util.UUID;

public class Order {
    private String orderId;
    private Basket basket;
    private String username;

    public Order(Basket basket, String username){
        this.basket = basket;
        this.username = username;
        this.orderId = UUID.randomUUID().toString().substring(0,8);
    }

    public Basket getBasket() { return basket; }
    public String getUsername() { return username; }
    public String getOrderId() { return orderId; }

    public void generateBill(Discount discount){
        System.out.println("\n=== Bill ===");
        double total = 0;
        for(Map.Entry<Product, Double> e : basket.getItems().entrySet()){
            Product p = e.getKey();
            double qty = e.getValue();
            double price = p.getPricePerKg() * qty;
            total += price;
            System.out.printf("%-5s %-15s %-10s %-5.2f %-7.2f\n",
                    p.getId(), p.getName(), p.getCategory(), qty, price);
        }
        if(discount != null){
            double discountAmount = discount.apply(total);
            System.out.println("Discount ("+discount.getName()+"): -" + discountAmount);
            total -= discountAmount;
        }
        System.out.println("Total: " + total);
        System.out.println("=============");
    }

    public String toCSV(){
        StringBuilder sb = new StringBuilder(orderId + "," + username);
        for(Map.Entry<Product, Double> e : basket.getItems().entrySet()) {
            sb.append(",").append(e.getKey().getId()).append(":").append(e.getValue());
        }
        return sb.toString();
    }

    public static Order fromCSV(String line){
        try {
            String[] parts = line.split(",");
            if(parts.length < 3) return null;
            Basket b = new Basket();
            String username = parts[1];
            for(int i = 2; i < parts.length; i++){
                String[] kv = parts[i].split(":");
                Product p = new Product(kv[0], kv[0], Category.OTHER, 1.0); // placeholder
                b.addItem(p, Double.parseDouble(kv[1]), false); // no print
            }
            return new Order(b, username);
        } catch(Exception e){ return null; }
    }
}
