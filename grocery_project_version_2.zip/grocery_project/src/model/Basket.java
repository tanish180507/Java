package model;

import java.util.HashMap;
import java.util.Map;

public class Basket {
    private Map<Product, Double> items = new HashMap<>();

    // Add item with optional print
    public void addItem(Product p, double qty, boolean printMessage) {
        if(p == null || qty <= 0) return;
        items.put(p, items.getOrDefault(p, 0.0) + qty);
        if(printMessage)
            System.out.println(qty + " kg of " + p.getName() + " added to basket.");
    }

    // Default addItem for manual user adds
    public void addItem(Product p, double qty) {
        addItem(p, qty, true);
    }

    // Remove an item completely
    public void removeItem(Product p) {
        if(p == null) return;
        if(items.containsKey(p)) {
            items.remove(p);
            System.out.println(p.getName() + " removed from basket.");
        } else {
            System.out.println("Product not found in basket.");
        }
    }

    public Map<Product, Double> getItems() {
        return items;
    }

    public void clear() {
        items.clear();
    }
}
