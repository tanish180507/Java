package model;

public class PercentageDiscount extends Discount {
    private double percent; // 10 means 10%

    public PercentageDiscount(String name, double percent){
        super(name);
        this.percent = percent;
    }

    @Override
    public double apply(double total){
        return total * (percent / 100.0);
    }
}
