package model;

public class FlatDiscount extends Discount {
    private double amount;

    public FlatDiscount(String name, double amount){
        super(name);
        this.amount = amount;
    }

    @Override
    public double apply(double total){
        return amount;
    }
}
