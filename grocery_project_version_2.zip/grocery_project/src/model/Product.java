package model;

public class Product {
    private String id;
    private String name;
    private Category category;
    private double pricePerKg;

    public Product(String id, String name, Category category, double pricePerKg) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.pricePerKg = pricePerKg;
    }

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public double getPricePerKg() { return pricePerKg; }
    public void setPricePerKg(double pricePerKg) { this.pricePerKg = pricePerKg; }

    // CSV serialization
    public String toCSV() {
        return id + "," + name + "," + category + "," + pricePerKg;
    }

    public static Product fromCSV(String line) {
        try {
            String[] parts = line.split(",");
            if (parts.length != 4) return null;
            String id = parts[0];
            String name = parts[1];
            Category cat = Category.fromString(parts[2]);
            double price = Double.parseDouble(parts[3]);
            return new Product(id, name, cat, price);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return String.format("%-5s %-15s %-10s %.2f", id, name, category, pricePerKg);
    }
}
