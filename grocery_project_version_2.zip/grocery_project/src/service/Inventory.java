package service;

import model.Product;
import model.Category;
import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Product> products = new ArrayList<>();

    // Add a new product
    public void addProduct(Product p){
        products.add(p);
        System.out.println("Product added successfully!");
    }

    // Update existing product
    public void updateProduct(Product p){
        for(int i=0; i<products.size(); i++){
            if(products.get(i).getId().equals(p.getId())){
                products.set(i, p);
                System.out.println("Product updated successfully!");
                return;
            }
        }
        System.out.println("Product not found!");
    }

    // Remove product by ID
    public void removeProduct(String id){
        products.removeIf(p -> p.getId().equals(id));
        System.out.println("Product removed successfully!");
    }

    // Get product by ID
    public Product getProductById(String id){
        for(Product p: products){
            if(p.getId().equals(id)) return p;
        }
        return null;
    }

    // Get all products
    public List<Product> getAllProducts(){
        return products;
    }

    // Search by name (case-insensitive, partial match)
    public List<Product> searchByName(String name){
        List<Product> result = new ArrayList<>();
        for(Product p : products){
            if(p.getName().toLowerCase().contains(name.toLowerCase())){
                result.add(p);
            }
        }
        return result;
    }

    // Search by category
    public List<Product> searchByCategory(Category category){
        List<Product> result = new ArrayList<>();
        for(Product p : products){
            if(p.getCategory() == category){
                result.add(p);
            }
        }
        return result;
    }
}
