package service;

import model.Category;
import java.util.*;

public class AdminDashboard {
    private static Map<Category, Double> categorySales = new HashMap<>();

    public static void addSales(Category c, double kg){
        categorySales.put(c, categorySales.getOrDefault(c,0.0)+kg);
    }

    public static void displayReport(){
        System.out.println("=== Category-wise Sales Report (kg) ===");
        for(Category c: Category.values()) {
            System.out.printf("%-10s : %.2f kg\n", c, categorySales.getOrDefault(c,0.0));
        }
    }
}
