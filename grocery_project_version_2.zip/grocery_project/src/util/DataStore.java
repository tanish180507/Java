package util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private static DataStore instance;

    private DataStore() {}

    public static DataStore getInstance() {
        if (instance == null) instance = new DataStore();
        return instance;
    }

    public List<String> readCSV(String filePath) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while((line = br.readLine()) != null) lines.add(line);
        } catch (IOException e) {}
        return lines;
    }

    public void writeCSV(String filePath, List<String> lines) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for(String line : lines) { bw.write(line); bw.newLine(); }
        } catch (IOException e) {}
    }

    public void appendCSV(String filePath, String line) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath,true))) {
            bw.write(line); bw.newLine();
        } catch(IOException e) {}
    }
}
