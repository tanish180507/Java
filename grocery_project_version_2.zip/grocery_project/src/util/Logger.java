package util;

import java.io.*;

public class Logger {
    private static Logger instance;
    private String logFile = "data/log.txt";

    private Logger() {
        try {
            File f = new File(logFile);
            if (!f.exists()) f.createNewFile();
        } catch(Exception e) {}
    }

    public static Logger getInstance() {
        if(instance == null) instance = new Logger();
        return instance;
    }

    public void log(String msg) {
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(logFile,true))) {
            bw.write(msg);
            bw.newLine();
        } catch(IOException e) {
            System.out.println("Error writing log: " + e.getMessage());
        }
    }
}
