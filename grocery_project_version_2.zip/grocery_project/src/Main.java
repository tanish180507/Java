import user.*;
import service.Inventory;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inventory inventory = new Inventory();
        UserManager um = new UserManager();

        int choice;
        do {
            System.out.println("\n=== Grocery Billing System ===");
            System.out.println("1. Admin Login");
            System.out.println("2. Consumer Login");
            System.out.println("0. Exit");
            choice = sc.nextInt(); sc.nextLine();

            switch(choice){
                case 1: // Admin login
                    System.out.print("Username: ");
                    String aUser = sc.nextLine();
                    System.out.print("Password: ");
                    String aPass = sc.nextLine();

                    if(um.login(aUser, aPass) && um.isAdmin(aUser)){
                        Admin admin = new Admin(aUser, inventory);
                        admin.displayMenu();
                    } else {
                        System.out.println("Invalid admin credentials!");
                    }
                    break;

                case 2: // Consumer login/registration
                    System.out.print("Username: ");
                    String cUser = sc.nextLine();
                    if(!um.userExists(cUser)){
                        System.out.print("New user! Enter password to register: ");
                        String cPass = sc.nextLine();
                        um.register(cUser, cPass);
                        System.out.println("Registered successfully!");
                    }

                    System.out.print("Enter password: ");
                    String cPass = sc.nextLine();
                    if(um.login(cUser, cPass)){
                        Consumer consumer = new Consumer(cUser, inventory);
                        consumer.displayMenu();
                    } else {
                        System.out.println("Invalid username/password!");
                    }
                    break;
            }

        } while(choice != 0);

        System.out.println("Exiting...");
        sc.close();
    }
}
