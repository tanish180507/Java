package user;

import service.Inventory;
import model.Basket;
import model.Product;
import model.Order;
import model.OrderHistory;
import model.Discount;
import model.PercentageDiscount;
import model.Category;

import java.util.Scanner;
import java.util.Map;
import java.util.List;

public class Consumer extends User {
    private Inventory inventory;
    private Scanner sc = new Scanner(System.in);
    private Basket basket = new Basket();
    private OrderHistory orderHistory = new OrderHistory();

    public Consumer(String name, Inventory inv){ 
        super(name); 
        inventory = inv; 
    }

    @Override
    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n--- Consumer Menu ---");
            System.out.println("1. List Products");
            System.out.println("2. Add to Basket");
            System.out.println("3. Remove from Basket");
            System.out.println("4. Checkout");
            System.out.println("5. View My Orders");
            System.out.println("6. Search Product");
            System.out.println("0. Logout");
            choice = sc.nextInt(); sc.nextLine();
            switch(choice){
                case 1: listProducts(); break;
                case 2: addToBasket(); break;
                case 3: removeFromBasket(); break;
                case 4: checkout(); break;
                case 5: viewMyOrders(); break;
                case 6: searchProduct(); break;
            }
        } while(choice != 0);
    }

    private void listProducts(){
        System.out.printf("%-5s %-15s %-10s %-5s\n","PID","Name","Category","Price");
        for(Product p: inventory.getAllProducts()) System.out.println(p);
    }

    private void addToBasket(){
        System.out.print("Enter Product ID: "); 
        String id = sc.nextLine();
        Product p = inventory.getProductById(id);
        if(p == null){ 
            System.out.println("Product not found!"); 
            return; 
        }
        System.out.print("Enter Quantity (kg): "); 
        double qty = sc.nextDouble(); sc.nextLine();
        basket.addItem(p, qty);
    }

    private void removeFromBasket() {
        if(basket.getItems().isEmpty()) {
            System.out.println("Basket is empty!");
            return;
        }

        System.out.print("Enter Product ID to remove: ");
        String id = sc.nextLine();
        Product p = inventory.getProductById(id);
        if(p == null) {
            System.out.println("Product not found!");
            return;
        }
        basket.removeItem(p);
    }

    private void checkout(){
        if(basket.getItems().isEmpty()){ 
            System.out.println("Basket is empty!"); 
            return; 
        }

        Order order = new Order(basket, this.getName());
        Discount discount = new PercentageDiscount("10% OFF", 10);
        order.generateBill(discount);

        orderHistory.addOrder(order);
        basket.clear();
    }

    private void viewMyOrders(){
        System.out.println("=== Your Order History ===");
        boolean hasOrders = false;
        for(Order o : orderHistory.getOrders()){
            if(o.getUsername().equals(this.getName())){
                hasOrders = true;
                System.out.println("Order ID: " + o.getOrderId());
                for(Map.Entry<Product, Double> e : o.getBasket().getItems().entrySet()){
                    Product p = e.getKey();
                    System.out.printf("%-5s %-15s %-10s %-5.2f %-7.2f\n",
                        p.getId(), p.getName(), p.getCategory(), e.getValue(), p.getPricePerKg()*e.getValue());
                }
                System.out.println("----------------------");
            }
        }
        if(!hasOrders) System.out.println("You have no orders yet.");
    }

    private void searchProduct(){
        System.out.println("Search by: 1. Name  2. Category");
        int choice = sc.nextInt(); sc.nextLine();
        List<Product> results = null;

        switch(choice){
            case 1:
                System.out.print("Enter product name to search: ");
                String name = sc.nextLine();
                results = inventory.searchByName(name);
                break;
            case 2:
                System.out.print("Enter category (e.g., FRUIT, DAIRY, OTHER): ");
                try {
                    String catStr = sc.nextLine().toUpperCase();
                    results = inventory.searchByCategory(Category.valueOf(catStr));
                } catch(Exception e){
                    System.out.println("Invalid category!");
                    return;
                }
                break;
            default:
                System.out.println("Invalid choice!");
                return;
        }

        if(results.isEmpty()){
            System.out.println("No products found.");
        } else {
            System.out.printf("%-5s %-15s %-10s %-5s\n","PID","Name","Category","Price");
            for(Product p : results){
                System.out.println(p);
            }
        }
    }
}
