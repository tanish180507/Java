package user;

import util.DataStore;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserManager {
    private Map<String,String> users = new HashMap<>();
    private DataStore ds = DataStore.getInstance();
    private String file = "data/users.csv";

    // Hardcoded admin password
    private final String ADMIN_USERNAME = "admin";
    private String adminPassword = "admin123";  // change this to whatever you want

    public UserManager() {
        loadUsers();
    }

    private void loadUsers() {
        List<String> lines = ds.readCSV(file);
        for(String line : lines) {
            String[] parts = line.split(",");
            if(parts.length == 2)
                users.put(parts[0].trim(), parts[1].trim());
        }
    }

    // Returns true if username/password match
    public boolean login(String username, String password){
        if(username == null || password == null) return false;

        // Check for admin first
        if(ADMIN_USERNAME.equalsIgnoreCase(username.trim())){
            return adminPassword.equals(password.trim());
        }

        // Check normal users
        return users.containsKey(username.trim()) &&
               users.get(username.trim()).equals(password.trim());
    }

    // Returns true if username is admin
    public boolean isAdmin(String username){
        return ADMIN_USERNAME.equalsIgnoreCase(username.trim());
    }

    // Returns true if user already exists (non-admin)
    public boolean userExists(String username){
        if(ADMIN_USERNAME.equalsIgnoreCase(username.trim())) return true;
        return users.containsKey(username.trim());
    }

    // Register new non-admin user
    public boolean register(String username, String password){
        if(ADMIN_USERNAME.equalsIgnoreCase(username.trim()) || users.containsKey(username.trim())) 
            return false;
        users.put(username.trim(), password.trim());
        ds.appendCSV(file, username.trim() + "," + password.trim());
        return true;
    }

    // Change admin password dynamically
    public boolean changeAdminPassword(String oldPass, String newPass){
        if(adminPassword.equals(oldPass)){
            adminPassword = newPass;
            return true;
        }
        return false;
    }
}
