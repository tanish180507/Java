package service;

import model.Product;
import util.DataStore;
import java.util.*;

public class Inventory {
    private List<Product> products;
    private DataStore ds;
    private String productFile = "data/products.csv";

    public Inventory() {
        ds = DataStore.getInstance();
        products = new ArrayList<>();
        loadProducts();
    }

    public void addProduct(Product p) { products.add(p); saveProducts(); }

    public void removeProduct(String id) {
        products.removeIf(p -> p.getId().equalsIgnoreCase(id));
        saveProducts();
    }

    public void updateProduct(Product updated) {
        for(int i=0;i<products.size();i++) {
            if(products.get(i).getId().equalsIgnoreCase(updated.getId())) { products.set(i, updated); break; }
        }
        saveProducts();
    }

    public Product getProductById(String id) {
        for(Product p : products) if(p.getId().equalsIgnoreCase(id)) return p;
        return null;
    }

    public List<Product> getAllProducts() { return products; }

    private void loadProducts() {
        List<String> lines = ds.readCSV(productFile);
        for(String line : lines) {
            Product p = Product.fromCSV(line);
            if(p!=null) products.add(p);
        }
    }

    private void saveProducts() {
        List<String> lines = new ArrayList<>();
        for(Product p : products) lines.add(p.toCSV());
        ds.writeCSV(productFile, lines);
    }
}
