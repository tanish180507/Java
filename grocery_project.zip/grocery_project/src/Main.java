import user.Admin;
import user.Consumer;
import service.Inventory;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Inventory inv = new Inventory();
        Scanner sc = new Scanner(System.in);
        int choice;
        do{
            System.out.println("\n=== Grocery Billing System ===");
            System.out.println("1. Admin Login\n2. Consumer Login\n0. Exit");
            choice = sc.nextInt(); sc.nextLine();
            switch(choice){
                case 1: Admin admin = new Admin("Admin", inv); admin.displayMenu(); break;
                case 2: Consumer c = new Consumer("Consumer", inv); c.displayMenu(); break;
            }
        } while(choice!=0);
        System.out.println("Thank you for using the system!");
    }
}
