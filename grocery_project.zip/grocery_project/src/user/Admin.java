package user;

import service.Inventory;
import model.Product;
import model.Category;
import service.AdminDashboard;
import java.util.Scanner;

public class Admin extends User {
    private Inventory inventory;
    private Scanner sc = new Scanner(System.in);

    public Admin(String name, Inventory inv){ super(name); inventory = inv; }

    @Override
    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add Product\n2. Update Product\n3. Remove Product\n4. View Inventory\n5. View Sales Report\n0. Logout");
            choice = sc.nextInt(); sc.nextLine();
            switch(choice){
                case 1: addProduct(); break;
                case 2: updateProduct(); break;
                case 3: removeProduct(); break;
                case 4: listInventory(); break;
                case 5: AdminDashboard.displayReport(); break;
            }
        } while(choice != 0);
    }

    private void addProduct(){
        System.out.print("Enter Product ID: "); String id = sc.nextLine();
        System.out.print("Enter Name: "); String name = sc.nextLine();
        System.out.print("Enter Category: "); Category cat = Category.fromString(sc.nextLine());
        System.out.print("Enter Price per kg: "); double price = sc.nextDouble(); sc.nextLine();
        inventory.addProduct(new Product(id,name,cat,price));
        System.out.println("Product added!");
    }

    private void updateProduct(){
        System.out.print("Enter Product ID to update: "); String id = sc.nextLine();
        Product p = inventory.getProductById(id);
        if(p==null){ System.out.println("Product not found!"); return; }
        System.out.print("Enter new Name: "); p.setName(sc.nextLine());
        System.out.print("Enter new Category: "); p.setCategory(Category.fromString(sc.nextLine()));
        System.out.print("Enter new Price per kg: "); p.setPricePerKg(sc.nextDouble()); sc.nextLine();
        inventory.updateProduct(p);
        System.out.println("Product updated!");
    }

    private void removeProduct(){
        System.out.print("Enter Product ID to remove: "); String id = sc.nextLine();
        inventory.removeProduct(id);
        System.out.println("Product removed if existed.");
    }

    private void listInventory(){
        System.out.println("--- Current Inventory ---");
        System.out.printf("%-5s %-15s %-10s %-5s\n","PID","Name","Category","Price");
        for(Product p: inventory.getAllProducts()) System.out.println(p);
    }
}
