package user;

import service.Inventory;
import model.Basket;
import model.Product;
import model.Order;
import java.util.Scanner;

public class Consumer extends User {
    private Inventory inventory;
    private Scanner sc = new Scanner(System.in);
    private Basket basket = new Basket();

    public Consumer(String name, Inventory inv){ super(name); inventory = inv; }

    @Override
    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n--- Consumer Menu ---");
            System.out.println("1. List Products\n2. Add to Basket\n3. Checkout\n0. Logout");
            choice = sc.nextInt(); sc.nextLine();
            switch(choice){
                case 1: listProducts(); break;
                case 2: addToBasket(); break;
                case 3: checkout(); break;
            }
        } while(choice!=0);
    }

    private void listProducts(){
        System.out.printf("%-5s %-15s %-10s %-5s\n","PID","Name","Category","Price");
        for(Product p: inventory.getAllProducts()) System.out.println(p);
    }

    private void addToBasket(){
        System.out.print("Enter Product ID: "); String id = sc.nextLine();
        Product p = inventory.getProductById(id);
        if(p==null){ System.out.println("Product not found!"); return; }
        System.out.print("Enter Quantity (kg): "); double qty = sc.nextDouble(); sc.nextLine();
        basket.addItem(p,qty);
        System.out.println("Added to basket!");
    }

    private void checkout(){
        if(basket.getItems().isEmpty()){ System.out.println("Basket is empty!"); return; }
        Order order = new Order(basket);
        order.generateBill();
        basket.clear();
    }
}
