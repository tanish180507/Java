package model;

import java.util.*;

public class Basket {
    private Map<Product, Double> items;

    public Basket() { items = new HashMap<>(); }

    public void addItem(Product p, double kg) {
        items.put(p, items.getOrDefault(p,0.0) + kg);
    }

    public void removeItem(Product p) { items.remove(p); }

    public Map<Product, Double> getItems() { return items; }

    public void clear() { items.clear(); }

    public double getTotal() {
        double sum=0;
        for(Map.Entry<Product,Double> e: items.entrySet())
            sum += e.getKey().getPricePerKg() * e.getValue();
        return sum;
    }
}
