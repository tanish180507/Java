package model;

public enum Category {
    VEGETABLES,
    FRUITS,
    DAIRY,
    BAKERY,
    HOUSEHOLD,
    OTHER;

    public static Category fromString(String str) {
        for (Category c : Category.values()) {
            if (c.name().equalsIgnoreCase(str)) {
                return c;
            }
        }
        return OTHER; // default
    }
}
