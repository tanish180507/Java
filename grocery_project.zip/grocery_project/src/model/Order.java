package model;

import java.util.*;
import util.DataStore;
import service.AdminDashboard;

public class Order {
    private static int idCounter = 1;
    private String orderId;
    private Basket basket;

    public Order(Basket b) {
        this.orderId = "O" + String.format("%05d", idCounter++);
        this.basket = b;
    }

    public void generateBill() {
        System.out.println("========== FINAL BILL ==========");
        System.out.println("Order ID: " + orderId);
        System.out.println("-------------------------------------------");
        System.out.printf("%-5s %-15s %-10s %-5s %-7s\n","PID","Name","Category","Kg","Amount");
        System.out.println("-------------------------------------------");
        for(Map.Entry<Product,Double> e : basket.getItems().entrySet()){
            Product p = e.getKey(); double kg = e.getValue();
            System.out.printf("%-5s %-15s %-10s %-5.2f %-7.2f\n", p.getId(), p.getName(), p.getCategory(), kg, p.getPricePerKg()*kg);
            AdminDashboard.addSales(p.getCategory(), kg);
        }
        System.out.println("-------------------------------------------");
        System.out.printf("TOTAL: %.2f\n", basket.getTotal());
        System.out.println("===========================================");
    }
}
